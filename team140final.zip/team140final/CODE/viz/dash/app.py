# -*- coding: utf-8 -*-

# Run this app with `python app.py` and
# visit http://127.0.0.1:8050/ in your web browser.

import dash
import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
import plotly.express as px
import pandas as pd
import plotly.graph_objects as go
import json
from datetime import datetime
from dash.dependencies import Input, Output
import os
import pickle
from distutils.version import LooseVersion
import dash_table
from dash_table.Format import Format, Scheme

'''
TODO:
    - Incorporate data from 1960 onwards?
    - [Done] Should users select the goal and year/decade for the world map?
        - Without goal selection, there maybe too many indicators in the drop down
    - Correlation table
    - Cloropleth scale seems a bit off, should move to quantiles?
    - Mist UI improvements - country name instead of code, friendly name of indicators etc
    - Update layout to create space for the table
    
'''

#Caching data - https://stackoverflow.com/questions/63225707/plotly-dash-refreshing-global-data-on-reload
#wdi_file = 'C:/Govind/Personal/OMSA/DVA/Project/source/cse6242-project/data/WDI_csv/WDI_csv/WDIData.csv'
DATASET = "SDG_PROCESSED"
external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
wdi_file = '../../data/WDIData.csv'
m49_country_codes = '../../data/M49_country_codes.csv'
rank_file = '../../data_post/ranks.csv'
processed_ind_file = '../../data_post/SDGI_complete_series.csv'
sdg3_meta = '../../data_post/SDGI_description.csv'
target_file = '../../data_post/SDGI_target_reached.csv'
CACHE_FOLDER = '../../data/cache'

# Use a cache for faster loading
if not os.path.exists(CACHE_FOLDER):
    os.makedirs(CACHE_FOLDER)


## GLOBAL State is stored in these 3 variables
selected_year = "2012"
selected_country = "SAU"
selected_goal = 0 # indexing starts from 0

# Get the geoJson
def load_geojson(from_web=False):
    #file = 'assets/ne_10m_admin_0_countries.geojson' # slow
    #file = 'assets/ne_50m_admin_0_countries.geojson' # faster
    file = 'assets/ne_110m_admin_0_countries.geojson' # fastest
    if from_web or not os.path.exists(file):
        from urllib.request import urlopen
        with urlopen('https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_10m_admin_0_countries.geojson') as response:
            x = json.load(response)
    else:
        #with open('assets/ne_10m_admin_0_countries.geojson') as fp:
        with open(file) as fp:
            x = json.load(fp)

    return x

countries = load_geojson()


# Default themes are available - https://www.bootstrapcdn.com/bootswatch/
app = dash.Dash(__name__, 
                external_stylesheets=[dbc.themes.COSMO, 'assets/mystyles.css'],
                title="DIPR - Team 140")



'''

DATA MANIPULATION

'''


# HDF can deal with Dataframes only, pickle is more generic
def save_to_cache(df, k, hdf = False):
    if hdf == True:
        file = CACHE_FOLDER + '/' + k + '.hd5'
        if not os.path.exists(file):
            df.to_hdf(file, key=k)
            return True
    else:
        file = CACHE_FOLDER + '/' + k + '.pickle'
        with open(file, 'wb') as f:
            pickle.dump(df, f, pickle.HIGHEST_PROTOCOL)
            return True
    
    return False
    
    

def load_from_cache(k, hdf = False):
    if hdf == True:
        file = CACHE_FOLDER + '/' + k + '.hd5'
        if os.path.exists(file):
            return pd.read_hdf(file, k)
    else:
        file = CACHE_FOLDER + '/' + k + '.pickle'
        if os.path.exists(file):
            with open(file, 'rb') as f:
                data = pickle.load(f)
                return data
    
    return None

def custom_sort_key(x):
    v = x['label'].split(' ')[0]
    v = v.split('.')
    #print(v)
    if v[1].isalpha():
        v[1] = ord(v[1]) - ord('a') + 10
    v1 = int(v[0]) * 1000 + int(v[1]) * 10 + int(v[2])
    #print(v1)
    return v1

def load_rank_csv():
    df = pd.read_csv(rank_file)
    return df[['SDG Indicator','Rank',	'Correlation Rank',	'Relative Rank',	'Weight',	'WDI']]

def load_interpolated_indicators():
    return pd.read_csv(processed_ind_file)

def get_top_x_wdi(df, sdg_code, top=5):
    x = df[df['SDG Indicator'] == sdg_code].sort_values(['Relative Rank', 'Rank'],axis=0, ascending=[True, True])[0:top]
    #x = x.round({'Weight': 2})
    x['No'] = pd.Series([1,2,3,4,5], index=x.index)
    app.logger.info(x)
    
    return x



year_cols = []
year_ddown = []
for i in range(0, 2021 - 1960):
    year_cols.append(str(1960 + i))
    year_ddown.append({'label':str(1960+i), 'value':str(1960+i)})

future_year_cols = []
for i in range(0, 2040 - 2021):
    future_year_cols.append(str(2021 + i))


ranks = load_rank_csv()

if DATASET == "SDG_PROCESSED":
    sdg_raw = [] # store as a list of dataframes for each sdg
    app.logger.info("{} Loading processed indicators ...".format(datetime.now()))
    m49_codes = pd.read_csv(m49_country_codes)
    target = pd.read_csv(target_file)
    target = target.merge(m49_codes, left_on='GeoAreaCode', right_on='GeoCode')
    target = target.rename(columns={"GeoAreaName": "country_name","IsoCode": "ccode"})
    

    path = processed_ind_file
    app.logger.info("{} Reading from {}".format(datetime.now(), path))
    
    s = pd.read_csv(path)
    s = s[['SeriesCode', 'GeoAreaName', 'TimePeriod', 'Value', 'Type', 'GeoAreaCode']]
    s = s.merge(m49_codes, left_on='GeoAreaCode', right_on='GeoCode')
    s = s.rename(columns={"GeoAreaName": "country_name",
                          "IsoCode": "ccode",
                          "SeriesCode": "icode",
                          #"SeriesDescription": "indicator_name",
                          "TimePeriod": "year",
                          "Value": "value"})
    s['year'] = s['year'].astype(str)
    s = s.dropna(axis=0, subset=["value"] ) # drop rows with NA value
    sdg_raw.append(s)

    wdi_melted = sdg_raw[selected_goal]
    x = pd.read_csv(sdg3_meta)
    # Drop indicators that don't have a WDI rank assigned
    xx = x[x['SeriesCode'].isin(ranks['SDG Indicator'])]
    # Drop indicators that don't have target analysis
    xx = xx[xx['SeriesCode'].isin(target.columns)]
    
    indicator_list = (xx.apply(lambda datum: {'label': datum['Indicator'] + ' ' + datum['SeriesDescription'], 'value': datum['SeriesCode']}, 1)
                  .to_list()) # .sort(key=lambda x: custom_sort_key(x))
    
    
    
    

    app.logger.info("{} Done".format(datetime.now()))
    
elif DATASET == "SDG":
    app.logger.info("{} Loading SDG Indicator database...".format(datetime.now()))

    
    m49_codes = pd.read_csv(m49_country_codes)
    sdg_raw = load_from_cache('sdg_all')
    if sdg_raw is None:
        sdg_raw = [] # store as a list of dataframes for each sdg
        # Load all SDG indicators into separate tables
        for i in range(0, 17):
            path = '../data/sdg_indicators/Goal{}.xlsx'.format(i+1)
            app.logger.info("{} Reading from {}".format(datetime.now(), path))
            #path = 'C:/Govind/Personal/OMSA/DVA/Project/source/cse6242-project/data/sdg_indicators/Goal{}.xlsx'.format(i+1)
            # xlsx doesn't work on latest pandas - https://stackoverflow.com/questions/65254535/xlrd-biffh-xlrderror-excel-xlsx-file-not-supported
            s = pd.read_excel(path, engine='openpyxl')
            # select
            s = s[['Goal', 'Target', 'Indicator', 'SeriesCode',
                   'SeriesDescription', 'GeoAreaCode', 'TimePeriod', 'Value', 'Units']]
            s = s.merge(m49_codes, left_on='GeoAreaCode', right_on='GeoCode')
            s = s.rename(columns={"CountryName": "country_name",
                                  "IsoCode": "ccode",
                                  "SeriesCode": "icode",
                                  "SeriesDescription": "indicator_name",
                                  "TimePeriod": "year",
                                  "Value": "value"})
            s['year'] = s['year'].astype(str)
            s = s.dropna(axis=0, subset=["value"] ) # drop rows with NA value
            sdg_raw.append(s)

            app.logger.info("{} Done".format(datetime.now()))
        save_to_cache(sdg_raw,'sdg_all')

    wdi_melted = sdg_raw[selected_goal]
    #wdi_filtered = sdg_raw[(sdg_raw['icode'] == selected_indicator) & (sdg_raw['year'] == selected_year)]
    app.logger.info("{} Done".format(datetime.now()))
    indicator_list = (wdi_melted.drop_duplicates(subset=['icode'])
                  .apply(lambda x: {'label': x['Indicator'] + ' ' + x['indicator_name'], 'value': x['icode']}, 1)
                  .to_list()) # .sort(key=lambda x: custom_sort_key(x))
    
elif DATASET == "WDI":
    selected_indicator = "NY.GDP.PCAP.CD"
    app.logger.info("{} Loading WDI Indicator database...".format(datetime.now()))
    wdi_melted = load_from_cache('wdi_melted')
    if wdi_melted is None:
        #wdi_raw = pd.read_csv(wdi_file, nrows=1000)
        wdi_raw = pd.read_csv(wdi_file)
        wdi_raw = wdi_raw.drop('Unnamed: 65', axis=1)  # drop last column
        wdi_raw = wdi_raw.rename(columns={"Country Name": "country_name",
                                          "Country Code": "ccode",
                                          "Indicator Code": "icode",
                                          "Indicator Name": "indicator_name"})
        wdi_melted = pd.melt(wdi_raw,
                             id_vars=["country_name", "ccode",
                                      "icode", "indicator_name"],
                             value_vars=year_cols,
                             var_name="year", value_name="value")
        wdi_melted = wdi_melted.dropna(axis=0, subset=["value"] ) # drop rows with NA value
        save_to_cache(wdi_melted, 'wdi_melted')
        # Filter out the {Indicator} for {Year}
        #wdi_filtered = wdi_melted[(wdi_melted['icode'] == selected_indicator) & (wdi_melted['year'] == selected_year)]

    app.logger.info("{} Done".format(datetime.now()))
    indicator_list = (wdi_melted.drop_duplicates(subset=['icode'])
                  .apply(lambda x: {'label': x['Indicator'] + ' ' + x['indicator_name'], 'value': x['icode']}, 1)
                  .to_list()) # .sort(key=lambda x: custom_sort_key(x))

def create_indicator_list(df):
    ilist = (df.drop_duplicates(subset=['icode'])
                  .apply(lambda x: {'label': x['Indicator'] + ' ' + x['indicator_name'], 'value': x['icode']}, 1)
                  .to_list())
    ilist = sorted(ilist,key=lambda x: custom_sort_key(x))
    
    return ilist



indicator_list = sorted(indicator_list,key=lambda x: custom_sort_key(x))
selected_indicator = indicator_list[0]['value'] # select 1st indicator

def create_random_predictions(val, lyear, rate=0.1, n=10):
    
    l = [{'year':lyear, 'value':val}] # store rows as a list
    try:
        for i in range(0, n):
            val = val*(1+rate)
            l.append({'year':future_year_cols[i], 'value':val})
    except Exception as e:
        app.logger.error("{}, {}, {}, {}".format(val, lyear, l, e))
    return pd.DataFrame(l) 
    

# filter all values of the  indicator over the years
def wdi_historical_vals(df, indicator, country, years=year_cols):
    if DATASET == "SDG_PROCESSED":
        past = df[(df['ccode'] == country) & (df['icode'] == indicator) & (df['Type'] == 'Actual')]
        future = df[(df['ccode'] == country) & (df['icode'] == indicator) & (df['Type'] != 'Actual')]
    else:
        past = df[(df['ccode'] == country) & (df['icode'] == indicator) & (df['year'].isin(years))]
        future = pd.DataFrame()
        if past.size > 0:
            last_val = past.iloc[-1]['value'] # Latest value, should be at the end
            last_year = past.iloc[-1]['year']
            # Append with projections
            future = create_random_predictions(float(last_val), last_year)
        
    return (past, future)

# The value of the indicator over the world for a given year
def wdi_world_vals(df, indicator, year):
    return df[(df['icode'] == indicator) & (df['year'] == year)]

def get_country_name(code):
    return m49_codes[m49_codes['IsoCode'] == code]['CountryName'].array[0]
    if DATASET == "SDG_PROCESSED":
        return code
    else:
        return m49_codes[m49_codes['IsoCode'] == code]['CountryName'].array[0]

def get_target_met(ind):
    df = pd.DataFrame(columns=["ccode", "value"])
    try:
        df = target[['ccode', ind]].dropna()
    except Exception as e:
        app.logger.error(e)
    return df

    


'''

USER INTERFACE ELEMENTS AND LAYOUT

'''

def create_world_map(df, ind, year):
    # https://github.com/nvkelso/natural-earth-vector/blob/master/geojson/ne_10m_admin_0_countries.geojson
    #https://stackoverflow.com/questions/59121224/how-to-create-a-choropleth-map-using-mapbox-and-plotly-at-a-country-level

    app.logger.info("{} Creating world map for indicator {},{} ".format(datetime.now(), ind, df.columns))
    #df = wdi_world_vals(df, ind, year)
    df = get_target_met(ind)
    app.logger.info("{} Map DF size = {} ".format(datetime.now(), df.size))
    if df.size == 0:
        df = pd.DataFrame(columns=["ccode", ind])
    #app.logger.info("{}".format(df)) 'properties.ADM0_A3' / ccode 'properties.BRK_NAME' / country name
    fig3 = px.choropleth_mapbox(df, geojson=countries, locations='ccode', 
                                featureidkey='properties.ADM0_A3', color=ind,
                                color_discrete_map={
                                True: "green",
                                False: "orange"},
                                #range_color=(0, 12),
                                mapbox_style="carto-positron",
                                zoom=2, center={"lat": 23.8, "lon": 45.0},
                                opacity=0.5,
                                labels={'value': ind, 'ccode':'Country', ind:'Meets Target'}
                                )
    fig3.update_geos(fitbounds="locations", visible=True)
    fig3.update_layout(margin={"r": 0, "t": 0, "l": 0, "b": 0})
    app.logger.info("{} ++++ Done Creating world map for indicator {},{} ".format(datetime.now(), ind, df.columns))
    
    return fig3

# For finer control over the map you need to use the Graphical Object API -
def create_world_map2(df, ind, year):
    # Data should be set in the parameter z
    # https://plotly.com/python-api-reference/generated/plotly.graph_objects.Choroplethmapbox.html
    # https://stackoverflow.com/questions/61601991/plotly-is-not-rendering-choropleth-mapbox-polygons
    
    pass


def create_trend_graph(df, ind, country):
    # Historical Graph - line chart - https://plotly.com/python/line-charts/#line-plot-with-plotlyexpress
    app.logger.info("{} Creating trend graph for indicator {}, country {} ".format(
        datetime.now(), ind, country))
    hist_vals, future_vals = wdi_historical_vals(df, ind, country)
    app.logger.info("Trend DF size = {} ".format(hist_vals.size))
    app.logger.info("Future DF size = {} ".format(future_vals.size))
    fig = go.Figure()
    if hist_vals.size > 0:
        df = df[(df['ccode'] == country) & (df['icode'] == ind)].sort_values('year', ascending=True)
        df1 = df.copy()
        df1.loc[df['Type'] != 'Actual', 'value'] = float('nan')
        app.logger.info(df)
        fig.add_trace(go.Scatter(x=df['year'], y=df['value'],
             mode='lines',
             #name='Actual',
             connectgaps = True,
             line={'dash': 'solid'}))
        fig.add_trace(go.Scatter(x=df1['year'], y=df1['value'],
                     mode='markers',
                     name='Actual',
                     connectgaps = True,
                     line={'dash': 'solid'}))
        df1 = df.copy()
        df1.loc[df['Type'] != 'Interpolation', 'value'] = float('nan')
        fig.add_trace(go.Scatter(x=df1['year'], y=df1['value'],
             mode='markers',
             name='Interpolated',
             #connectgaps = True,
             line={'dash': 'dash'}))
        df1 = df.copy()
        df1.loc[df['Type'] != 'Prediction', 'value'] = float('nan')
        fig.add_trace(go.Scatter(x=df1['year'], y=df1['value'],
             mode='markers',
             name='Prediction',
             #connectgaps = True,
             line={'dash': 'dash'}))

        
    '''
    if future_vals.size > 0:
        fig.add_trace(go.Scatter(x=future_vals['year'], y=future_vals['value'],
                             mode='lines',
                             name='Forecast',
                             line={'dash': 'dash'}))
    fig = go.Figure()
    if hist_vals.size > 0:
        fig.add_trace(go.Scatter(x=hist_vals['year'], y=hist_vals['value'],
                                 mode='lines',
                                 name='Past',
                                 line={'dash': 'solid'}))
    if future_vals.size > 0:
        fig.add_trace(go.Scatter(x=future_vals['year'], y=future_vals['value'],
                             mode='lines',
                             name='Forecast',
                             line={'dash': 'dash'}))
    '''
    # Edit the layout -> https://plotly.com/python/reference/layout/
    fig.update_layout(title=dict(text='Trend for ' + ind + ' in ' + get_country_name(country),
                      x=0.5),
                      xaxis_title="Years",
                      yaxis_title=ind,
                      legend = dict(font = dict(family = "Courier", size = 12, color = "black"),
                                    yanchor="top",
                                    y=1.1,
                                    xanchor="right",
                                    x=0.99),
                      legend_title = dict(font = dict(family = "Courier", size = 15, color = "blue")),
                      legend_orientation ='h',
                      margin= dict(l = 10, r = 10, t=70, b=10)
                      )
    
    app.logger.info("{} === Done creating trend graph for indicator {}, country {} ".format(
        datetime.now(), ind, country))
    return fig

# fig2.layout["width"] = 2000
# fig2.layout["height"] = 1000
# fig2.layout.xaxis.fixedrange = True
# fig2.layout.yaxis.fixedrange = True


#fig_map = create_world_map(wdi_melted, selected_indicator, selected_year)
#fig_trend = create_trend_graph(wdi_melted, selected_indicator, selected_country) E-WEB-Goal-01

# 17 Goals
goal_buttons = []
for i in range(0, 17):
    disable = True
    if i == 2:
        disable = False
    goal_buttons.append(html.Button(
            #"Goal {}".format(i+1), 
            id='goal-{}'.format(i), # use 0 based indexing
            disabled=disable,
            className="sdg-btn",
            style={'backgroundImage':'url(assets/sdg_icons/E-WEB-Goal-{:02d}.png)'.format(i+1), 
                   'backgroundSize':'100%', #fill dimensions of container
                   'width':'75px',
                   'height':'75px'})) 

# Many many indicators https://stackoverflow.com/questions/63592900/plotly-dash-how-to-design-the-layout-using-dash-bootstrap-components

indicator_ui = dbc.Card(
    dbc.CardBody([
        dbc.CardHeader("Select SDG Indicator",className="wdi-card-header",style={'fontWeight':'bold'}),
        dcc.Dropdown(
            id='demo-dropdown',
            options=indicator_list,
            clearable=False,
            #style={'height': '45px'},      # Height of the box itself
            optionHeight=70,                # Height of the elements inside the drop down list
            value=selected_indicator),      # default selection
        #dbc.CardFooter(id="wdi-card-footer")
    ]))

year_dropdown_ui = dbc.Card(
    dbc.CardBody([
        dcc.Dropdown(
            id='year-dropdown',
            options=year_ddown,
            clearable=False,
            #style={'height': '45px'},      # Height of the box itself
            #optionHeight=70,                # Height of the elements inside the drop down list
            value=selected_year),      # default selection
    ]))


# In reactjs, CSS style selectors have to be camenCased instead of what is defined in CSS spec - https://reactjs.org/docs/dom-elements.html#style

app.layout = html.Div(children=[
    html.H1(children='SDG Dashboard - Team 140'),

    # html.Div(children='''
    #     Dash: A web application framework for Python.
    # '''),

    dbc.Row(goal_buttons),
    dbc.Row([dbc.Col(year_dropdown_ui, width=1), dbc.Col(indicator_ui, width=6)]),
    html.Br(),
    dbc.Row(
        [
            # dbc.Card(
            #     dbc.CardBody([
            #dbc.Col(indicator_ui,width=3),
            dbc.Col(dcc.Graph(
                id='choropleth-map',
                figure=create_world_map(wdi_melted, selected_indicator, selected_year),
                config={'displayModeBar': False}
            ), width=8),

            dbc.Col(
                dbc.Card(
                    dbc.CardBody([
                        dcc.Graph(
                            id='trend-graph',
                            figure=create_trend_graph(wdi_melted, selected_indicator, selected_country),
                            config={'displayModeBar': False})

                    ])))
        ]
    ),
    html.Br(),
    dbc.Row(
        [

        ]
    ),

    # dcc.Graph(
    #     id='example-graph',
    #     figure=fig,
    #     config={'displayModeBar': False}
    # )
])


def drawFigure():
    return  html.Div([
        dbc.Card(
            dbc.CardBody([
                dcc.Graph(
                    figure=px.bar(
                        px.data.iris(), x="sepal_width", y="sepal_length", color="species"
                    ).update_layout(
                        template='plotly_dark',
                        plot_bgcolor= 'rgba(0, 0, 0, 0)',
                        paper_bgcolor= 'rgba(0, 0, 0, 0)',
                    ),
                    config={
                        'displayModeBar': False
                    }
                ) 
            ])
        ),  
    ])

# "format":Format(precision=2, scheme=Scheme.fixed)
app.layout = html.Div([
    dbc.Card(
        dbc.CardBody([
            dbc.Row(goal_buttons, align='center'), 
            html.Br(),
            dbc.Row([
                dbc.Col([
                    dbc.Row([
                        #dbc.Col(year_dropdown_ui, width=2),
                        dbc.Col([
                            indicator_ui
                        ], width=12)
                    ]),
                    
                    dbc.Row([
                        dbc.Col([
                            dcc.Graph(
                            id='choropleth-map',
                            figure=create_world_map(wdi_melted, selected_indicator, selected_year),
                            config={'displayModeBar': False}
                        )
                        ], width=12)
                    ]),
                    dbc.Row([
                        dbc.Col([
                            html.Br(),
                            html.Label("Top related WDI Indicators",
                                       style={'fontWeight':'bold'}),
                            dash_table.DataTable(
                                    id='rank-table',
                                    columns=[{"name": i, "id": i, 'type':'numeric'} for i in ['No', 'WDI']], #ranks.columns
                                    data=get_top_x_wdi(ranks, selected_indicator).to_dict('records'),
                                    style_cell={'textAlign': 'left'},
                                    style_data_conditional=[
                                        {
                                            'if': {'row_index': 'odd'},
                                            'backgroundColor': 'rgb(248, 248, 248)'
                                        }
                                    ],
                                    style_header={
                                        'backgroundColor': 'rgb(230, 230, 230)',
                                        'fontWeight': 'bold'
                                    }
                                )
                            ], align="center")],justify="center", align="center")
                ], width=8),
                dbc.Col([
                    # dbc.Row([
                    #     dbc.Col([
                    #         drawFigure() 
                    #     ], width=12)
                    # ]),
                    
                    dbc.Row([
                        dbc.Col([
                        dcc.Graph(
                            id='trend-graph',
                            figure=create_trend_graph(wdi_melted, selected_indicator, selected_country),
                            config={'displayModeBar': False})
                        ], width=12)
                    ])
                ], width=4)
                
            ], align='top'), 
            html.Br(),
            # dbc.Row([
            #     dbc.Col([
            #         drawFigure()
            #     ], width=9),
            #     dbc.Col([
            #         drawFigure()
            #     ], width=3),
            # ], align='center'),      
        ]), color = 'light'
    )
])


'''

CALLBACK SECTION

'''

# @app.callback(
#     dash.dependencies.Output('wdi-card-footer', 'children'),
#     [dash.dependencies.Input('demo-dropdown', 'value')])
# def debug_selector(value):
#     return 'You have selected "{}"'.format(value)

@app.callback(
    dash.dependencies.Output('choropleth-map', 'figure'),
    dash.dependencies.Output('rank-table', 'data'),
    [dash.dependencies.Input('demo-dropdown', 'value'),
     #dash.dependencies.Input('year-dropdown', 'value')
     ])
def on_selected_indicator(indicator):
    global selected_indicator
    global selected_year
    selected_indicator = indicator
    #selected_year = year
    app.logger.info("{} Updating map component".format(datetime.now()))
    #df = wdi_world_vals(wdi_melted, selected_indicator, selected_year)
    fig = create_world_map(wdi_melted, selected_indicator, selected_year)

    data = get_top_x_wdi(ranks, selected_indicator).to_dict('records')
    if not fig:
        fig = go.Figure(data=[go.Scatter(x=[], y=[])])

    app.logger.info("{} +++ Done Updating map component".format(datetime.now()))
    return fig, data


@app.callback(
    dash.dependencies.Output('trend-graph', 'figure'),
    dash.dependencies.Input('choropleth-map', 'clickData'),
    dash.dependencies.Input('demo-dropdown', 'value'))
def on_clicked_country(x,y):
    #app.logger.info(json.dumps(clickData, indent=2)) # prints onto the python console
    # { "points": [ { "curveNumber": 0, "pointNumber": 82, "pointIndex": 82, "location": "CAN", "z": 46313.17137129611 } ] }
    fig = None
    global selected_country
    if x != None and type(x) is dict:
        selected_country = x['points'][0]['location']

    fig = create_trend_graph(wdi_melted, selected_indicator, selected_country)

    if not fig:
        fig = go.Figure(data=[go.Scatter(x=[], y=[])])

    return fig

'''
@app.callback(Output('demo-dropdown', 'options'),
              Output('demo-dropdown', 'value'),
              Input('goal-0', 'n_clicks'),
              Input('goal-1', 'n_clicks'),
              Input('goal-2', 'n_clicks'),
              Input('goal-3', 'n_clicks'),
              Input('goal-4', 'n_clicks'),
              Input('goal-5', 'n_clicks'),
              Input('goal-6', 'n_clicks'),
              Input('goal-7', 'n_clicks'),
              Input('goal-8', 'n_clicks'),
              Input('goal-9', 'n_clicks'),
              Input('goal-10', 'n_clicks'),
              Input('goal-11', 'n_clicks'),
              Input('goal-12', 'n_clicks'),
              Input('goal-13', 'n_clicks'),
              Input('goal-14', 'n_clicks'),
              Input('goal-15', 'n_clicks'),
              Input('goal-16', 'n_clicks'))
def on_goal_selected(*args):
    changed_id = [p['prop_id'] for p in dash.callback_context.triggered][0]
    global selected_goal
    global wdi_melted
    global selected_indicator
    
    app.logger.info("Changed ID = {}".format(changed_id)) # goal-1.n_clicks
    ilist = []
    if(len(changed_id) > 5):
        selected_goal = int(changed_id.split('.')[0].split('-')[1])
        
        wdi_melted = sdg_raw[selected_goal]
        app.logger.info("Selecting goal: {}".format(selected_goal))
        ilist = create_indicator_list(wdi_melted)
        selected_indicator = ilist[0]['value'] # select 1st indicator
        app.logger.info("Selsected Indicator: {}".format(selected_indicator))
        return ilist, selected_indicator
    else:
        return indicator_list, selected_indicator
'''    

if __name__ == '__main__':
    app.run_server(debug=False)
